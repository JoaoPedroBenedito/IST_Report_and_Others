#include "image.h"
#include <stdlib.h>
#include <stdio.h>

//#define NUM_LIN 64
//#define NUM_COL 128

#define MAX(x,y) ((x>y)?x:y)
#define MIN(x,y) ((x>y)?y:x)

#define GREY_LEVELS 256


int main(void)
{
	image I;
	int i,j;

	read_image(&I,"lena.pgm");

	//compute negative
	for(i=0; i < (I.height); i++)
		for(j=0; j < (I.width); j++)
			I.pixels[i*I.width+j] = GREY_LEVELS - I.pixels[i*I.width+j] - 1;

	write_image(&I,"lena_negative.pgm");
	free_image(&I);

	return;
}
