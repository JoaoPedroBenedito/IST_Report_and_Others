#include "image.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//Routine for allocate image
void alloc_image(image *I)
{
	I->pixels = (pixel*)malloc(I->width*I->height*sizeof(pixel)); 

	if(!I->pixels)
	{
		printf("Not enough memory\n");
		exit(-1);
	}

	return;
}

//Routine for freeing image
void free_image(image *I)
{
	if(I->pixels)
	{
		free(I->pixels);
	}

	return;
}


//Routine for reading an input image
void read_image(image *I, const char file_name[])
{
	char s[128];
	FILE *f;
	int i,j;

	f=fopen(file_name,"rb"); if(!f) printf("Error opening image file\n"), exit(-1);

	for(i=0 ; i<3 ; i++){
		fgets(s,99,f);
		if(s[0]=='#') //it is a comment
			i--;
		else if(i==1)
			sscanf(s,"%d %d",&I->width,&I->height);
	}

	alloc_image(I);

	for(i=0; i < I->height; i++)
		for(j=0; j < I->width; j++)
			I->pixels[i*I->width+j] = (unsigned char)fgetc(f); 

	fclose(f);

	return;
}

//Routine for writing an output image
void write_image(image *I, const char file_name[])
{
	FILE *f;
	int i,j;

	f=fopen(file_name,"wb");

	fprintf(f,"P5\n%d %d\n255\n",I->width,I->height);
	
	//write reducion result to file
	for(i=0 ; i<I->height ; i++)
		for(j=0 ; j<I->width ; j++)
			fputc(I->pixels[i*I->width+j], f);
		
	fclose(f);
	return;
}
