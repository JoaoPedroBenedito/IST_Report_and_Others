#ifndef _IMAGE_H_
#define _IMAGE_H_

#define _CRT_SECURE_NO_DEPRECATE

typedef unsigned char pixel;

typedef struct IMAGE{
	int width;
	int height;
	pixel *pixels;
} image;

//Routine for allocate image
void alloc_image(image *I);

//Routine for freeing image
void free_image(image *I);

//Routine for reading an input image
void read_image(image *I, const char file_name[]);

//Routine for writing an output image
void write_image(image *I, const char file_name[]);

#endif // _IMAGE_H_